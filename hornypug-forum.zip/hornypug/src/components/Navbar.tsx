import Link from 'next/link'
import { useRouter } from 'next/router'
import { useState, useEffect } from 'react'
import styles from './Navbar.module.css'

interface User {
  userId: string
  username: string
  role: string
  avatar_color?: string
}

export default function Navbar() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    fetch('/api/auth/me')
      .then(r => r.json())
      .then(d => { if (d.user) setUser(d.user) })
      .catch(() => {})
  }, [router.pathname])

  const logout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' })
    setUser(null)
    router.push('/')
  }

  const initials = (name: string) => name.slice(0, 2).toUpperCase()
  const avatarColor = user?.avatar_color || '#f97316'

  return (
    <nav className={styles.nav}>
      <div className={`container ${styles.inner}`}>
        {/* Logo */}
        <Link href="/" className={styles.logo}>
          <span className={styles.logoPug}>🐾</span>
          <span>Horny<span className={styles.logoAccent}>Pug</span></span>
        </Link>

        {/* Desktop Links */}
        <div className={`${styles.links} hide-mobile`}>
          <Link href="/forum" className={router.pathname.startsWith('/forum') ? styles.linkActive : styles.link}>Форум</Link>
          <Link href="/chat" className={router.pathname === '/chat' ? styles.linkActive : styles.link}>💬 Чат</Link>
          <Link href="/members" className={router.pathname === '/members' ? styles.linkActive : styles.link}>Участники</Link>
        </div>

        {/* Right side */}
        <div className={styles.right}>
          {user ? (
            <div className={styles.userMenu}>
              {user.role === 'admin' && (
                <Link href="/admin" className={`btn btn-sm ${styles.adminBtn}`}>👑 Панель</Link>
              )}
              <div className={styles.userBtn} onClick={() => setMenuOpen(!menuOpen)}>
                <div className="avatar avatar-sm" style={{ background: avatarColor }}>{initials(user.username)}</div>
                <span className={`hide-mobile ${styles.userName}`}>{user.username}</span>
                <span className={styles.chevron}>{menuOpen ? '▲' : '▼'}</span>
              </div>
              {menuOpen && (
                <div className={styles.dropdown}>
                  <Link href={`/user/${user.username}`} className={styles.dropItem} onClick={() => setMenuOpen(false)}>👤 Мой профиль</Link>
                  <Link href="/settings" className={styles.dropItem} onClick={() => setMenuOpen(false)}>⚙️ Настройки</Link>
                  {user.role === 'admin' && (
                    <Link href="/admin" className={styles.dropItem} onClick={() => setMenuOpen(false)}>👑 Панель управления</Link>
                  )}
                  <div className={styles.dropDivider} />
                  <button className={`${styles.dropItem} ${styles.dropDanger}`} onClick={logout}>🚪 Выйти</button>
                </div>
              )}
            </div>
          ) : (
            <div className="flex gap-2">
              <Link href="/login" className="btn btn-ghost btn-sm">Войти</Link>
              <Link href="/register" className="btn btn-primary btn-sm">Регистрация</Link>
            </div>
          )}

          {/* Mobile burger */}
          <button className={`${styles.burger} show-mobile`} onClick={() => setMenuOpen(!menuOpen)}>☰</button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className={`${styles.mobileMenu} show-mobile`}>
          <Link href="/forum" className={styles.mobileLink} onClick={() => setMenuOpen(false)}>💬 Форум</Link>
          <Link href="/chat" className={styles.mobileLink} onClick={() => setMenuOpen(false)}>💬 Чат</Link>
          <Link href="/members" className={styles.mobileLink} onClick={() => setMenuOpen(false)}>👥 Участники</Link>
          {user ? (
            <>
              <Link href={`/user/${user.username}`} className={styles.mobileLink} onClick={() => setMenuOpen(false)}>👤 Профиль</Link>
              <button className={styles.mobileLink} onClick={logout}>🚪 Выйти</button>
            </>
          ) : (
            <>
              <Link href="/login" className={styles.mobileLink} onClick={() => setMenuOpen(false)}>Войти</Link>
              <Link href="/register" className={styles.mobileLink} onClick={() => setMenuOpen(false)}>Регистрация</Link>
            </>
          )}
        </div>
      )}
    </nav>
  )
}
