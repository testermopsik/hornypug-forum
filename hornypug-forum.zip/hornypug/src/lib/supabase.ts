import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

// Клиент для браузера (read-only через RLS)
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Серверный клиент с полным доступом (только в API routes!)
export const supabaseAdmin = () => {
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!serviceKey) {
    // В dev режиме используем anon key с предупреждением
    console.warn('SUPABASE_SERVICE_ROLE_KEY not set, using anon key')
    return createClient(supabaseUrl, supabaseAnonKey)
  }
  return createClient(supabaseUrl, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false }
  })
}
