import { useState, useEffect } from 'react'
import Head from 'next/head'
import Link from 'next/link'
import Navbar from '@/components/Navbar'
import styles from './members.module.css'

interface Member {
  id: string
  username: string
  role: string
  avatar_color: string
  reputation: number
  created_at: string
}

export default function Members() {
  const [members, setMembers] = useState<Member[]>([])
  const [search, setSearch] = useState('')
  const [sort, setSort] = useState<'rep' | 'new'>('rep')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    fetch(`/api/members?search=${encodeURIComponent(search)}&sort=${sort}`)
      .then(r => r.json())
      .then(d => { setMembers(d.members || []); setLoading(false) })
  }, [search, sort])

  const initials = (n: string) => n.slice(0, 2).toUpperCase()
  const joinedDate = (d: string) => new Date(d).toLocaleDateString('ru', { year: 'numeric', month: 'long' })

  const roleLabel: Record<string, string> = { admin: '👑 Admin', mod: '🛡️ Mod', user: '' }

  return (
    <>
      <Head><title>Участники — Horny Pug</title></Head>
      <Navbar />
      <div className={`container ${styles.page}`}>
        <div className={styles.header}>
          <h1 className={styles.title}>👥 УЧАСТНИКИ</h1>
          <p className={styles.sub}>Познакомься с сообществом Horny Pug</p>
        </div>

        <div className={styles.controls}>
          <input
            className={`input ${styles.searchInput}`}
            placeholder="🔍 Поиск по нику..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <div className={styles.sortBtns}>
            <button className={`${styles.sortBtn} ${sort === 'rep' ? styles.sortActive : ''}`} onClick={() => setSort('rep')}>
              ⭐ По репутации
            </button>
            <button className={`${styles.sortBtn} ${sort === 'new' ? styles.sortActive : ''}`} onClick={() => setSort('new')}>
              🕐 Новые
            </button>
          </div>
        </div>

        {loading ? (
          <div className={styles.grid}>
            {Array(12).fill(0).map((_, i) => (
              <div key={i} className={`skeleton ${styles.skeletonCard}`} />
            ))}
          </div>
        ) : members.length === 0 ? (
          <div className={styles.empty}>
            <div className={styles.emptyIcon}>👤</div>
            <p>Никого не найдено</p>
          </div>
        ) : (
          <div className={styles.grid}>
            {members.map((m, i) => (
              <Link key={m.id} href={`/user/${m.username}`} className={styles.card}>
                {i < 3 && <div className={styles.topBadge}>{['🥇','🥈','🥉'][i]}</div>}
                <div className={`avatar avatar-lg ${styles.cardAvatar}`} style={{ background: m.avatar_color }}>
                  {initials(m.username)}
                </div>
                <div className={styles.cardName}>{m.username}</div>
                {roleLabel[m.role] && (
                  <div className={`badge ${m.role === 'admin' ? 'badge-admin' : 'badge-mod'} ${styles.roleBadge}`}>
                    {roleLabel[m.role]}
                  </div>
                )}
                <div className={styles.cardRep}>⭐ {m.reputation.toLocaleString('ru')}</div>
                <div className={styles.cardJoined}>с {joinedDate(m.created_at)}</div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </>
  )
}
