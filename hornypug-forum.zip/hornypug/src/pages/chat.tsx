import { useState, useEffect, useRef } from 'react'
import Head from 'next/head'
import Link from 'next/link'
import { useRouter } from 'next/router'
import Navbar from '@/components/Navbar'
import styles from './chat.module.css'

interface Message {
  id: string
  body: string
  created_at: string
  users: { id: string; username: string; avatar_color: string; role: string } | null
}

export default function Chat() {
  const router = useRouter()
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [user, setUser] = useState<{ userId: string; username: string; role: string; avatar_color?: string } | null>(null)
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)
  const pollRef = useRef<ReturnType<typeof setInterval>>()

  const fetchMessages = async () => {
    const r = await fetch('/api/chat')
    const d = await r.json()
    setMessages(d.messages || [])
    setLoading(false)
  }

  useEffect(() => {
    fetch('/api/auth/me').then(r => r.json()).then(d => setUser(d.user))
    fetchMessages()
    // Poll every 3s
    pollRef.current = setInterval(fetchMessages, 3000)
    return () => clearInterval(pollRef.current)
  }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const send = async () => {
    if (!user) { router.push('/login'); return }
    if (!input.trim() || sending) return
    setSending(true)
    const optimistic: Message = {
      id: 'opt-' + Date.now(),
      body: input.trim(),
      created_at: new Date().toISOString(),
      users: { id: user.userId, username: user.username, avatar_color: user.avatar_color || '#f97316', role: user.role }
    }
    setMessages(prev => [...prev, optimistic])
    setInput('')
    await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ body: optimistic.body }),
    })
    setSending(false)
    fetchMessages()
  }

  const initials = (n: string) => n.slice(0, 2).toUpperCase()
  const formatTime = (ts: string) => new Date(ts).toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' })

  return (
    <>
      <Head><title>Чат — Horny Pug</title></Head>
      <Navbar />
      <div className={styles.chatPage}>
        <div className={styles.chatLayout}>
          <div className={styles.chatMain}>
            <div className={styles.chatHeader}>
              <h1 className={styles.chatTitle}>💬 Живой чат</h1>
              <span className={styles.onlineBadge}>
                <span className={styles.onlineDot}/> онлайн
              </span>
            </div>

            <div className={styles.messages}>
              {loading ? (
                <div className={styles.chatLoading}>⟳ Загрузка...</div>
              ) : messages.length === 0 ? (
                <div className={styles.chatEmpty}>
                  <div style={{ fontSize: 48, marginBottom: 12 }}>🐾</div>
                  <p>Нет сообщений. Начни первым!</p>
                </div>
              ) : (
                messages.map((msg, i) => {
                  const isMe = msg.users?.id === user?.userId
                  const prevSame = i > 0 && messages[i-1].users?.id === msg.users?.id
                  return (
                    <div key={msg.id} className={`${styles.msgWrap} ${isMe ? styles.msgWrapMe : ''}`}>
                      {!prevSame && !isMe && (
                        <div className="avatar avatar-sm" style={{ background: msg.users?.avatar_color || '#f97316', flexShrink: 0, alignSelf: 'flex-end' }}>
                          {initials(msg.users?.username || '?')}
                        </div>
                      )}
                      {prevSame && !isMe && <div style={{ width: 32 }} />}
                      <div className={`${styles.msgBubble} ${isMe ? styles.msgBubbleMe : ''}`}>
                        {!prevSame && !isMe && (
                          <div className={styles.msgAuthor}>
                            {msg.users?.username}
                            {msg.users?.role === 'admin' && <span className="badge badge-admin" style={{fontSize:9}}>👑</span>}
                          </div>
                        )}
                        <p className={styles.msgText}>{msg.body}</p>
                        <span className={styles.msgTime}>{formatTime(msg.created_at)}</span>
                      </div>
                    </div>
                  )
                })
              )}
              <div ref={bottomRef} />
            </div>

            {/* Input */}
            <div className={styles.inputArea}>
              {user ? (
                <>
                  <div className="avatar avatar-sm" style={{ background: user.avatar_color || '#f97316', flexShrink: 0 }}>
                    {initials(user.username)}
                  </div>
                  <input
                    className={styles.chatInput}
                    placeholder="Напиши сообщение..."
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
                    maxLength={500}
                  />
                  <button className={`btn btn-primary ${styles.sendBtn}`} onClick={send} disabled={!input.trim() || sending}>
                    {sending ? '⟳' : '→'}
                  </button>
                </>
              ) : (
                <div className={styles.loginPrompt}>
                  <Link href="/login" className="btn btn-primary btn-sm">Войди</Link>
                  <span style={{ color: 'var(--text2)', fontSize: 14 }}>чтобы участвовать в чате</span>
                </div>
              )}
            </div>
          </div>

          {/* Right panel */}
          <aside className={`${styles.chatSidebar} hide-mobile`}>
            <div className="card">
              <div className="card-body">
                <h3 style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 20, letterSpacing: 1, marginBottom: 16 }}>📜 Правила чата</h3>
                <ul style={{ fontSize: 13, color: 'var(--text2)', paddingLeft: 16, lineHeight: 2.2 }}>
                  <li>Без спама и флуда</li>
                  <li>Уважай других</li>
                  <li>Без оскорблений</li>
                  <li>Без рекламы</li>
                </ul>
              </div>
            </div>
            <div className="card" style={{ marginTop: 16 }}>
              <div className="card-body">
                <h3 style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 20, letterSpacing: 1, marginBottom: 12 }}>🔗 Переход</h3>
                <Link href="/forum" className="btn btn-ghost w-full" style={{ justifyContent: 'center' }}>← Форум</Link>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </>
  )
}
