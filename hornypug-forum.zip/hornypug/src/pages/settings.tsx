import { useState, useEffect } from 'react'
import Head from 'next/head'
import { useRouter } from 'next/router'
import Navbar from '@/components/Navbar'
import styles from './settings.module.css'

const COLORS = [
  '#f97316','#fb923c','#f59e0b','#eab308',
  '#22c55e','#10b981','#38bdf8','#818cf8',
  '#e879f9','#f43f5e','#ef4444','#ffffff',
]

export default function Settings() {
  const router = useRouter()
  const [user, setUser] = useState<{ userId: string; username: string; avatar_color: string } | null>(null)
  const [bio, setBio] = useState('')
  const [color, setColor] = useState('#f97316')
  const [oldPass, setOldPass] = useState('')
  const [newPass, setNewPass] = useState('')
  const [newPass2, setNewPass2] = useState('')
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetch('/api/auth/me').then(r => r.json()).then(d => {
      if (!d.user) { router.push('/login'); return }
      setUser(d.user)
      setColor(d.user.avatar_color || '#f97316')
      // Fetch full profile for bio
      fetch(`/api/users/${d.user.username}`).then(r => r.json()).then(p => {
        if (p.bio) setBio(p.bio)
      })
    })
  }, [router])

  const saveProfile = async () => {
    setLoading(true); setMsg(null)
    const r = await fetch('/api/settings/profile', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ bio, avatar_color: color }),
    })
    const d = await r.json()
    setLoading(false)
    setMsg(r.ok ? { type: 'success', text: '✅ Профиль обновлён!' } : { type: 'error', text: d.error })
  }

  const changePassword = async () => {
    if (!oldPass || !newPass) return setMsg({ type: 'error', text: 'Заполни все поля' })
    if (newPass !== newPass2) return setMsg({ type: 'error', text: 'Пароли не совпадают' })
    if (newPass.length < 6) return setMsg({ type: 'error', text: 'Минимум 6 символов' })
    setLoading(true); setMsg(null)
    const r = await fetch('/api/settings/password', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ oldPassword: oldPass, newPassword: newPass }),
    })
    const d = await r.json()
    setLoading(false)
    if (r.ok) {
      setMsg({ type: 'success', text: '✅ Пароль изменён!' })
      setOldPass(''); setNewPass(''); setNewPass2('')
    } else {
      setMsg({ type: 'error', text: d.error })
    }
  }

  if (!user) return null

  const initials = user.username.slice(0, 2).toUpperCase()

  return (
    <>
      <Head><title>Настройки — Horny Pug</title></Head>
      <Navbar />
      <div className={`container ${styles.page}`}>
        <h1 className={styles.pageTitle}>⚙️ НАСТРОЙКИ</h1>

        {msg && (
          <div className={`alert alert-${msg.type} ${styles.alert}`}>{msg.text}</div>
        )}

        {/* Profile settings */}
        <div className={`card ${styles.section}`}>
          <div className="card-header">
            <h2 className={styles.sectionTitle}>👤 Профиль</h2>
          </div>
          <div className="card-body">
            <div className={styles.avatarPreview}>
              <div className={`avatar avatar-xl`} style={{ background: color }}>{initials}</div>
              <div className={styles.avatarInfo}>
                <div className={styles.avatarName}>{user.username}</div>
                <div className={styles.avatarSub}>Выбери цвет аватара</div>
              </div>
            </div>

            <div className={styles.colorGrid}>
              {COLORS.map(c => (
                <button
                  key={c}
                  className={`${styles.colorBtn} ${color === c ? styles.colorActive : ''}`}
                  style={{ background: c }}
                  onClick={() => setColor(c)}
                  title={c}
                />
              ))}
            </div>

            <div className="field" style={{ marginTop: 20 }}>
              <label className="input-label">О себе</label>
              <textarea
                className="input"
                placeholder="Расскажи немного о себе..."
                value={bio}
                onChange={e => setBio(e.target.value)}
                maxLength={300}
                rows={3}
              />
              <div className={styles.charCount}>{bio.length}/300</div>
            </div>

            <button className="btn btn-primary" onClick={saveProfile} disabled={loading}>
              {loading ? '⏳ Сохраняем...' : '💾 Сохранить профиль'}
            </button>
          </div>
        </div>

        {/* Password change */}
        <div className={`card ${styles.section}`}>
          <div className="card-header">
            <h2 className={styles.sectionTitle}>🔐 Сменить пароль</h2>
          </div>
          <div className="card-body">
            <div className="field">
              <label className="input-label">Текущий пароль</label>
              <input type="password" className="input" placeholder="••••••••" value={oldPass} onChange={e => setOldPass(e.target.value)} />
            </div>
            <div className="field">
              <label className="input-label">Новый пароль</label>
              <input type="password" className="input" placeholder="минимум 6 символов" value={newPass} onChange={e => setNewPass(e.target.value)} />
            </div>
            <div className="field">
              <label className="input-label">Повторить новый пароль</label>
              <input type="password" className="input" placeholder="••••••••" value={newPass2} onChange={e => setNewPass2(e.target.value)} />
            </div>
            <button className="btn btn-ghost" onClick={changePassword} disabled={loading}>
              {loading ? '⏳' : '🔑 Изменить пароль'}
            </button>
          </div>
        </div>

        {/* Danger zone */}
        <div className={`card ${styles.section} ${styles.dangerCard}`}>
          <div className="card-header">
            <h2 className={styles.sectionTitle} style={{ color: 'var(--red)' }}>⚠️ Опасная зона</h2>
          </div>
          <div className="card-body">
            <p className={styles.dangerText}>Удаление аккаунта нельзя отменить. Все твои посты будут удалены.</p>
            <button className="btn btn-danger" onClick={() => {
              if (confirm('Точно удалить аккаунт? Это действие необратимо!')) {
                fetch('/api/settings/delete', { method: 'DELETE' }).then(() => router.push('/'))
              }
            }}>
              🗑️ Удалить аккаунт
            </button>
          </div>
        </div>
      </div>
    </>
  )
}
