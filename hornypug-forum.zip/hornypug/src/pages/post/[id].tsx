import { useState } from 'react'
import { GetServerSideProps } from 'next'
import Link from 'next/link'
import Head from 'next/head'
import { useRouter } from 'next/router'
import Navbar from '@/components/Navbar'
import { supabaseAdmin } from '@/lib/supabase'
import { getSession } from '@/lib/auth'
import styles from './post.module.css'

interface User { id: string; username: string; avatar_color: string; role: string; reputation?: number }
interface Comment { id: string; body: string; created_at: string; users: User | null }
interface Post {
  id: string; title: string; body: string;
  is_pinned: boolean; is_locked: boolean; views: number; created_at: string;
  users: User | null
  categories: { id: number; name: string; slug: string; icon: string; color: string } | null
  reactions: Array<{ user_id: string }>
}

interface Props {
  post: Post
  comments: Comment[]
  session: { userId: string; username: string; role: string } | null
}

export default function PostPage({ post, comments: initComments, session }: Props) {
  const router = useRouter()
  const [comments, setComments] = useState(initComments)
  const [reply, setReply] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')
  const [liked, setLiked] = useState(session ? post.reactions.some(r => r.user_id === session.userId) : false)
  const [likeCount, setLikeCount] = useState(post.reactions.length)

  const initials = (n: string) => n.slice(0, 2).toUpperCase()
  const timeAgo = (ts: string) => {
    const d = Date.now() - new Date(ts).getTime()
    if (d < 60000) return 'только что'
    if (d < 3600000) return `${Math.floor(d/60000)} мин назад`
    if (d < 86400000) return `${Math.floor(d/3600000)} ч назад`
    return new Date(ts).toLocaleDateString('ru', { day: 'numeric', month: 'short' })
  }

  const submitComment = async () => {
    if (!reply.trim()) return
    setError(''); setSubmitting(true)
    const r = await fetch('/api/comments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ post_id: post.id, body: reply.trim() }),
    })
    const d = await r.json()
    setSubmitting(false)
    if (!r.ok) { setError(d.error); return }
    setComments([...comments, d.comment])
    setReply('')
  }

  const toggleLike = async () => {
    if (!session) { router.push('/login'); return }
    const r = await fetch('/api/reactions/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ post_id: post.id }),
    })
    const d = await r.json()
    setLiked(d.liked)
    setLikeCount(prev => d.liked ? prev + 1 : prev - 1)
  }

  const deletePost = async () => {
    if (!confirm('Удалить пост?')) return
    await fetch(`/api/posts/${post.id}`, { method: 'DELETE' })
    router.push('/forum')
  }

  const isAdmin = session?.role === 'admin' || session?.role === 'mod'

  return (
    <>
      <Head><title>{post.title} — Horny Pug</title></Head>
      <Navbar />
      <div className="container" style={{ paddingTop: 32, paddingBottom: 80 }}>
        <div className={styles.layout}>
          <main className={styles.main}>
            {/* Breadcrumb */}
            <div className={styles.breadcrumb}>
              <Link href="/forum">Форум</Link>
              {post.categories && (
                <>
                  <span>›</span>
                  <Link href={`/forum?cat=${post.categories.slug}`}>
                    {post.categories.icon} {post.categories.name}
                  </Link>
                </>
              )}
            </div>

            {/* Post */}
            <article className={styles.post}>
              {post.is_pinned && <div className="badge badge-pinned" style={{ marginBottom: 12 }}>📌 Закреплён</div>}
              {post.is_locked && <div className="badge badge-banned" style={{ marginBottom: 12, marginLeft: 8 }}>🔒 Закрыт</div>}
              <h1 className={styles.postTitle}>{post.title}</h1>
              <div className={styles.postMeta}>
                <div className="avatar avatar-md" style={{ background: post.users?.avatar_color || '#f97316' }}>
                  {initials(post.users?.username || '?')}
                </div>
                <div>
                  <div className={styles.postAuthor}>
                    <Link href={`/user/${post.users?.username}`}>{post.users?.username || 'Удалён'}</Link>
                    {post.users?.role === 'admin' && <span className="badge badge-admin">👑 Admin</span>}
                    {post.users?.role === 'mod' && <span className="badge badge-mod">🛡️ Mod</span>}
                  </div>
                  <div style={{ fontSize: 13, color: 'var(--text3)' }}>{timeAgo(post.created_at)} · 👁️ {post.views}</div>
                </div>
                {(session?.userId === post.users?.id || isAdmin) && (
                  <button className="btn btn-danger btn-sm" style={{ marginLeft: 'auto' }} onClick={deletePost}>🗑️ Удалить</button>
                )}
              </div>
              <div className={styles.postBody}>{post.body}</div>
              <div className={styles.postActions}>
                <button className={`${styles.likeBtn} ${liked ? styles.liked : ''}`} onClick={toggleLike}>
                  {liked ? '❤️' : '🤍'} <span>{likeCount}</span>
                </button>
                <span style={{ color: 'var(--text3)', fontSize: 13 }}>💬 {comments.length} комментариев</span>
              </div>
            </article>

            {/* Comments */}
            <div className={styles.commentsSection}>
              <h2 className={styles.commentsTitle}>Комментарии ({comments.length})</h2>

              {comments.map((c, i) => (
                <div key={c.id} className={styles.comment} style={{ animationDelay: `${i * 0.04}s` }}>
                  <div className="avatar avatar-sm" style={{ background: c.users?.avatar_color || '#f97316', flexShrink: 0 }}>
                    {initials(c.users?.username || '?')}
                  </div>
                  <div className={styles.commentBody}>
                    <div className={styles.commentMeta}>
                      <Link href={`/user/${c.users?.username}`} className={styles.commentAuthor}>
                        {c.users?.username || 'Удалён'}
                      </Link>
                      {c.users?.role === 'admin' && <span className="badge badge-admin" style={{ fontSize: 10 }}>👑</span>}
                      <span style={{ color: 'var(--text3)', fontSize: 12 }}>{timeAgo(c.created_at)}</span>
                    </div>
                    <p className={styles.commentText}>{c.body}</p>
                  </div>
                </div>
              ))}

              {/* Reply box */}
              {session && !post.is_locked && (
                <div className={styles.replyBox}>
                  <div className="avatar avatar-sm" style={{ background: '#f97316', flexShrink: 0 }}>
                    {initials(session.username)}
                  </div>
                  <div style={{ flex: 1 }}>
                    {error && <div className="alert alert-error">{error}</div>}
                    <textarea
                      className="input"
                      placeholder="Напиши комментарий..."
                      rows={3}
                      value={reply}
                      onChange={e => setReply(e.target.value)}
                    />
                    <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
                      <button className="btn btn-primary btn-sm" onClick={submitComment} disabled={submitting || !reply.trim()}>
                        {submitting ? '⟳' : '💬 Ответить'}
                      </button>
                    </div>
                  </div>
                </div>
              )}
              {!session && (
                <div className={styles.loginPrompt}>
                  <Link href="/login" className="btn btn-primary btn-sm">Войди</Link>
                  <span style={{ color: 'var(--text2)', fontSize: 14 }}>чтобы написать комментарий</span>
                </div>
              )}
              {post.is_locked && (
                <div className="alert alert-info">🔒 Комментарии закрыты для этого поста</div>
              )}
            </div>
          </main>

          {/* Sidebar */}
          <aside className={`${styles.sidebar} hide-mobile`}>
            {post.users && (
              <div className="card">
                <div className="card-body">
                  <h3 style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 18, letterSpacing: 1, marginBottom: 16 }}>Автор</h3>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div className="avatar avatar-lg" style={{ background: post.users.avatar_color }}>
                      {initials(post.users.username)}
                    </div>
                    <div>
                      <div style={{ fontWeight: 800, fontSize: 15 }}>{post.users.username}</div>
                      {post.users.role === 'admin' && <span className="badge badge-admin">👑 Admin</span>}
                      {post.users.reputation !== undefined && (
                        <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 4 }}>⭐ {post.users.reputation} репутации</div>
                      )}
                    </div>
                  </div>
                  <Link href={`/user/${post.users.username}`} className="btn btn-ghost w-full" style={{ justifyContent: 'center', marginTop: 16 }}>
                    Профиль →
                  </Link>
                </div>
              </div>
            )}
            {post.categories && (
              <div className="card" style={{ marginTop: 16 }}>
                <div className="card-body">
                  <h3 style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 18, letterSpacing: 1, marginBottom: 12 }}>Раздел</h3>
                  <Link
                    href={`/forum?cat=${post.categories.slug}`}
                    className="btn btn-ghost w-full"
                    style={{ justifyContent: 'center', color: post.categories.color }}
                  >
                    {post.categories.icon} {post.categories.name}
                  </Link>
                </div>
              </div>
            )}
          </aside>
        </div>
      </div>
    </>
  )
}

export const getServerSideProps: GetServerSideProps = async (ctx) => {
  const { id } = ctx.params as { id: string }
  const db = supabaseAdmin()
  const session = await getSession()

  const [{ data: post }, { data: comments }] = await Promise.all([
    db.from('posts')
      .select('id, title, body, is_pinned, is_locked, views, created_at, users!posts_user_id_fkey(id, username, avatar_color, role, reputation), categories!posts_category_id_fkey(id, name, slug, icon, color), reactions(user_id)')
      .eq('id', id).eq('is_deleted', false).single(),
    db.from('comments')
      .select('id, body, created_at, users!comments_user_id_fkey(id, username, avatar_color, role)')
      .eq('post_id', id).eq('is_deleted', false).order('created_at', { ascending: true }),
  ])

  if (!post) return { notFound: true }

  // increment views
  await db.rpc('increment_views', { post_id: id })

  return { props: { post, comments: comments || [], session } }
}
