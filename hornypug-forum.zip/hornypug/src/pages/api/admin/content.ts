import type { NextApiRequest, NextApiResponse } from 'next'
import { parse } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const cookies = parse(req.headers.cookie || '')
  const session = await verifyToken(cookies.hp_token || '')
  if (!session || session.role !== 'admin')
    return res.status(403).json({ error: 'Нет прав' })

  const db = supabaseAdmin()

  // GET categories + announcements
  if (req.method === 'GET') {
    const [cats, announces] = await Promise.all([
      db.from('categories').select('*').order('sort_order'),
      db.from('announcements').select('*').order('created_at', { ascending: false }).limit(10),
    ])
    return res.status(200).json({ categories: cats.data || [], announcements: announces.data || [] })
  }

  // POST create category or announcement
  if (req.method === 'POST') {
    const { type, ...data } = req.body

    if (type === 'category') {
      const { name, description, icon, color } = data
      if (!name) return res.status(400).json({ error: 'Название обязательно' })
      const slug = name.toLowerCase().replace(/[^a-zа-яё0-9]/gi, '-').replace(/-+/g, '-')
      const { data: cat, error } = await db
        .from('categories')
        .insert({ name, slug, description: description || '', icon: icon || '💬', color: color || '#6c63ff' })
        .select()
        .single()
      if (error) return res.status(400).json({ error: 'Категория уже существует' })
      return res.status(200).json({ category: cat })
    }

    if (type === 'announcement') {
      const { title, body } = data
      if (!title || !body) return res.status(400).json({ error: 'Заполни все поля' })
      await db.from('announcements').insert({ title, body, created_by: session.userId })
      return res.status(200).json({ ok: true })
    }

    return res.status(400).json({ error: 'Unknown type' })
  }

  // DELETE
  if (req.method === 'DELETE') {
    const { type, id } = req.body
    if (type === 'category') await db.from('categories').delete().eq('id', id)
    if (type === 'announcement') await db.from('announcements').delete().eq('id', id)
    return res.status(200).json({ ok: true })
  }

  return res.status(405).end()
}
