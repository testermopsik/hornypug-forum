import type { NextApiRequest, NextApiResponse } from 'next'
import { parse } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

async function requireAdmin(req: NextApiRequest, res: NextApiResponse) {
  const cookies = parse(req.headers.cookie || '')
  const session = await verifyToken(cookies.hp_token || '')
  if (!session || session.role !== 'admin') {
    res.status(403).json({ error: 'Нет прав' })
    return null
  }
  return session
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const db = supabaseAdmin()
  const session = await requireAdmin(req, res)
  if (!session) return

  // GET all users
  if (req.method === 'GET') {
    const { search = '' } = req.query
    let query = db
      .from('users')
      .select('id, username, role, avatar_color, reputation, is_banned, ban_reason, created_at, last_seen')
      .order('created_at', { ascending: false })
    if (search) query = query.ilike('username', `%${search}%`)
    const { data } = await query
    return res.status(200).json({ users: data || [] })
  }

  // PATCH — ban/unban/role
  if (req.method === 'PATCH') {
    const { userId, action, reason, role } = req.body

    if (userId === session.userId)
      return res.status(400).json({ error: 'Нельзя изменить свой аккаунт' })

    if (action === 'ban') {
      await db.from('users').update({ is_banned: true, ban_reason: reason || 'Нарушение правил' }).eq('id', userId)
      await db.from('ban_log').insert({ user_id: userId, admin_id: session.userId, action: 'ban', reason: reason || '' })
      return res.status(200).json({ ok: true })
    }
    if (action === 'unban') {
      await db.from('users').update({ is_banned: false, ban_reason: '' }).eq('id', userId)
      await db.from('ban_log').insert({ user_id: userId, admin_id: session.userId, action: 'unban', reason: '' })
      return res.status(200).json({ ok: true })
    }
    if (action === 'role' && role) {
      await db.from('users').update({ role }).eq('id', userId)
      return res.status(200).json({ ok: true })
    }
    return res.status(400).json({ error: 'Неизвестное действие' })
  }

  // DELETE user
  if (req.method === 'DELETE') {
    const { userId } = req.body
    if (userId === session.userId)
      return res.status(400).json({ error: 'Нельзя удалить себя' })
    await db.from('users').delete().eq('id', userId)
    return res.status(200).json({ ok: true })
  }

  return res.status(405).end()
}
