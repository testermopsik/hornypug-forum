import type { NextApiRequest, NextApiResponse } from 'next'
import { parse } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

async function requireAdmin(req: NextApiRequest, res: NextApiResponse) {
  const cookies = parse(req.headers.cookie || '')
  const session = await verifyToken(cookies.hp_token || '')
  if (!session || session.role !== 'admin') { res.status(403).json({ error: 'Нет прав' }); return null }
  return session
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const db = supabaseAdmin()
  const { type } = req.query

  const session = await requireAdmin(req, res)
  if (!session) return

  // ── STATS ──
  if (type === 'stats' && req.method === 'GET') {
    const [{ count: users }, { count: posts }, { count: comments }, { count: banned }, { count: msgs }] = await Promise.all([
      db.from('users').select('*', { count: 'exact', head: true }),
      db.from('posts').select('*', { count: 'exact', head: true }).eq('is_deleted', false),
      db.from('comments').select('*', { count: 'exact', head: true }).eq('is_deleted', false),
      db.from('users').select('*', { count: 'exact', head: true }).eq('is_banned', true),
      db.from('chat_messages').select('*', { count: 'exact', head: true }),
    ])
    return res.status(200).json({ users, posts, comments, banned, messages: msgs })
  }

  // ── CATEGORIES ──
  if (type === 'categories') {
    if (req.method === 'GET') {
      const { data } = await db.from('categories').select('*').order('sort_order')
      return res.status(200).json({ categories: data })
    }
    if (req.method === 'POST') {
      const { name, slug, description, icon, color } = req.body
      if (!name || !slug) return res.status(400).json({ error: 'Название и slug обязательны' })
      const { data, error } = await db.from('categories').insert({ name, slug, description, icon: icon||'💬', color: color||'#f97316' }).select().single()
      if (error) return res.status(400).json({ error: 'Slug уже занят' })
      return res.status(200).json({ category: data })
    }
    if (req.method === 'DELETE') {
      const { id } = req.body
      await db.from('categories').delete().eq('id', id)
      return res.status(200).json({ ok: true })
    }
  }

  // ── SETTINGS ──
  if (type === 'settings') {
    if (req.method === 'GET') {
      const { data } = await db.from('site_settings').select('*')
      const obj: Record<string, string> = {}
      data?.forEach(r => { obj[r.key] = r.value })
      return res.status(200).json({ settings: obj })
    }
    if (req.method === 'PATCH') {
      const { settings } = req.body
      for (const [key, value] of Object.entries(settings)) {
        await db.from('site_settings').upsert({ key, value: String(value), updated_at: new Date().toISOString() })
      }
      return res.status(200).json({ ok: true })
    }
  }

  // ── ANNOUNCEMENTS ──
  if (type === 'announcements') {
    if (req.method === 'GET') {
      const { data } = await db.from('announcements').select('*').order('created_at', { ascending: false })
      return res.status(200).json({ announcements: data })
    }
    if (req.method === 'POST') {
      const { title, body } = req.body
      if (!title || !body) return res.status(400).json({ error: 'Заполни поля' })
      const { data } = await db.from('announcements').insert({ title, body, created_by: session.userId }).select().single()
      return res.status(200).json({ announcement: data })
    }
    if (req.method === 'DELETE') {
      const { id } = req.body
      await db.from('announcements').delete().eq('id', id)
      return res.status(200).json({ ok: true })
    }
  }

  // ── POSTS MODERATION ──
  if (type === 'posts') {
    if (req.method === 'GET') {
      const { data } = await db
        .from('posts')
        .select('id, title, is_pinned, is_locked, is_deleted, created_at, users!posts_user_id_fkey(username)')
        .order('created_at', { ascending: false })
        .limit(100)
      return res.status(200).json({ posts: data })
    }
    if (req.method === 'PATCH') {
      const { postId, action } = req.body
      if (action === 'pin') await db.from('posts').update({ is_pinned: true }).eq('id', postId)
      if (action === 'unpin') await db.from('posts').update({ is_pinned: false }).eq('id', postId)
      if (action === 'lock') await db.from('posts').update({ is_locked: true }).eq('id', postId)
      if (action === 'unlock') await db.from('posts').update({ is_locked: false }).eq('id', postId)
      if (action === 'delete') await db.from('posts').update({ is_deleted: true }).eq('id', postId)
      if (action === 'restore') await db.from('posts').update({ is_deleted: false }).eq('id', postId)
      return res.status(200).json({ ok: true })
    }
  }

  return res.status(400).json({ error: 'Неизвестный тип' })
}
