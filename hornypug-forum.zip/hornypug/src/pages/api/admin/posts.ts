import type { NextApiRequest, NextApiResponse } from 'next'
import { parse } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const cookies = parse(req.headers.cookie || '')
  const session = await verifyToken(cookies.hp_token || '')
  if (!session || !['admin', 'mod'].includes(session.role))
    return res.status(403).json({ error: 'Нет прав' })

  const db = supabaseAdmin()

  if (req.method === 'GET') {
    const { page = '1', search = '' } = req.query
    const pageNum = parseInt(page as string)
    const from = (pageNum - 1) * 30

    let query = db
      .from('posts')
      .select(`
        id, title, is_pinned, is_locked, is_deleted, views, created_at,
        users!posts_user_id_fkey(username),
        categories!posts_category_id_fkey(name)
      `, { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(from, from + 29)

    if (search) query = query.ilike('title', `%${search}%`)

    const { data, count } = await query
    return res.status(200).json({ posts: data || [], total: count })
  }

  if (req.method === 'PATCH') {
    const { postId, action } = req.body
    if (!postId || !action) return res.status(400).json({ error: 'Missing fields' })

    if (action === 'pin') await db.from('posts').update({ is_pinned: true }).eq('id', postId)
    if (action === 'unpin') await db.from('posts').update({ is_pinned: false }).eq('id', postId)
    if (action === 'lock') await db.from('posts').update({ is_locked: true }).eq('id', postId)
    if (action === 'unlock') await db.from('posts').update({ is_locked: false }).eq('id', postId)
    if (action === 'delete') await db.from('posts').update({ is_deleted: true }).eq('id', postId)
    if (action === 'restore') await db.from('posts').update({ is_deleted: false }).eq('id', postId)

    return res.status(200).json({ ok: true })
  }

  return res.status(405).end()
}
