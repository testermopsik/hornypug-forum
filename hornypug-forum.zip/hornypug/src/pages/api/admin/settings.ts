import type { NextApiRequest, NextApiResponse } from 'next'
import { parse } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

async function requireAdmin(req: NextApiRequest) {
  const cookies = parse(req.headers.cookie || '')
  const session = await verifyToken(cookies.hp_token || '')
  if (!session || session.role !== 'admin') return null
  return session
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await requireAdmin(req)
  if (!session) return res.status(403).json({ error: 'Только для администраторов' })

  const db = supabaseAdmin()

  if (req.method === 'GET') {
    const [users, posts, comments, reactions, messages] = await Promise.all([
      db.from('users').select('id', { count: 'exact', head: true }),
      db.from('posts').select('id', { count: 'exact', head: true }).eq('is_deleted', false),
      db.from('comments').select('id', { count: 'exact', head: true }).eq('is_deleted', false),
      db.from('reactions').select('id', { count: 'exact', head: true }),
      db.from('chat_messages').select('id', { count: 'exact', head: true }),
    ])
    const { data: settings } = await db.from('site_settings').select('key, value')
    const { data: recentUsers } = await db
      .from('users')
      .select('id, username, role, reputation, is_banned, avatar_color, created_at')
      .order('created_at', { ascending: false })
      .limit(5)

    return res.status(200).json({
      stats: {
        users: users.count || 0,
        posts: posts.count || 0,
        comments: comments.count || 0,
        reactions: reactions.count || 0,
        messages: messages.count || 0,
      },
      settings: Object.fromEntries((settings || []).map(s => [s.key, s.value])),
      recentUsers: recentUsers || [],
    })
  }

  if (req.method === 'PATCH') {
    const { settings } = req.body
    if (!settings || typeof settings !== 'object') return res.status(400).json({ error: 'Invalid' })

    for (const [key, value] of Object.entries(settings)) {
      await db.from('site_settings')
        .upsert({ key, value: String(value), updated_at: new Date().toISOString() })
    }
    return res.status(200).json({ ok: true })
  }

  return res.status(405).end()
}
