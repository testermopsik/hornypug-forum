import type { NextApiRequest, NextApiResponse } from 'next'
import { parse } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const db = supabaseAdmin()

  if (req.method !== 'POST') return res.status(405).end()

  const cookies = parse(req.headers.cookie || '')
  const session = await verifyToken(cookies.hp_token || '')
  if (!session) return res.status(401).json({ error: 'Войди' })

  const { post_id, body } = req.body
  if (!post_id || !body?.trim()) return res.status(400).json({ error: 'Заполни поле' })
  if (body.length > 2000) return res.status(400).json({ error: 'Комментарий слишком длинный' })

  // Check post exists and not locked
  const { data: post } = await db.from('posts').select('is_locked, is_deleted').eq('id', post_id).single()
  if (!post || post.is_deleted) return res.status(404).json({ error: 'Пост не найден' })
  if (post.is_locked && !['admin','mod'].includes(session.role))
    return res.status(403).json({ error: 'Пост заблокирован для комментариев' })

  const { data: comment, error } = await db
    .from('comments')
    .insert({ post_id, user_id: session.userId, body: body.trim() })
    .select(`id, body, created_at, users!comments_user_id_fkey(id, username, avatar_color, role)`)
    .single()

  if (error) return res.status(500).json({ error: error.message })
  await db.rpc('update_reputation', { uid: session.userId, delta: 2 })

  return res.status(200).json({ comment })
}
