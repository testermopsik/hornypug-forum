import type { NextApiRequest, NextApiResponse } from 'next'
import bcrypt from 'bcryptjs'
import { parse } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'PATCH') return res.status(405).end()

  const cookies = parse(req.headers.cookie || '')
  const session = await verifyToken(cookies.hp_token || '')
  if (!session) return res.status(401).json({ error: 'Войди' })

  const { oldPassword, newPassword } = req.body
  if (!oldPassword || !newPassword) return res.status(400).json({ error: 'Заполни все поля' })
  if (newPassword.length < 6) return res.status(400).json({ error: 'Пароль минимум 6 символов' })

  const db = supabaseAdmin()
  const { data: user } = await db.from('users').select('password').eq('id', session.userId).single()
  if (!user) return res.status(404).json({ error: 'Пользователь не найден' })

  const valid = await bcrypt.compare(oldPassword, user.password)
  if (!valid) return res.status(400).json({ error: 'Неверный текущий пароль' })

  const hash = await bcrypt.hash(newPassword, 12)
  await db.from('users').update({ password: hash }).eq('id', session.userId)
  return res.status(200).json({ ok: true })
}
