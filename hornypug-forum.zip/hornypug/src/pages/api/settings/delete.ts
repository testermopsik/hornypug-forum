import type { NextApiRequest, NextApiResponse } from 'next'
import { parse, serialize } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'DELETE') return res.status(405).end()

  const cookies = parse(req.headers.cookie || '')
  const session = await verifyToken(cookies.hp_token || '')
  if (!session) return res.status(401).json({ error: 'Войди' })

  const db = supabaseAdmin()

  // Soft-delete posts
  await db.from('posts').update({ is_deleted: true }).eq('user_id', session.userId)
  // Hard-delete user
  await db.from('users').delete().eq('id', session.userId)

  // Clear cookie
  res.setHeader('Set-Cookie', serialize('hp_token', '', { maxAge: 0, path: '/' }))
  return res.status(200).json({ ok: true })
}
