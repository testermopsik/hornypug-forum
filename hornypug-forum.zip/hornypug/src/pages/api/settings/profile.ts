import type { NextApiRequest, NextApiResponse } from 'next'
import { parse } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const cookies = parse(req.headers.cookie || '')
  const session = await verifyToken(cookies.hp_token || '')
  if (!session) return res.status(401).json({ error: 'Войди' })

  const db = supabaseAdmin()

  if (req.method === 'PATCH') {
    const { bio, avatar_color } = req.body

    const updates: Record<string, string> = {}
    if (bio !== undefined) updates.bio = bio.slice(0, 300)
    if (avatar_color) updates.avatar_color = avatar_color

    if (Object.keys(updates).length === 0)
      return res.status(400).json({ error: 'Нет данных' })

    await db.from('users').update(updates).eq('id', session.userId)
    return res.status(200).json({ ok: true })
  }

  return res.status(405).end()
}
