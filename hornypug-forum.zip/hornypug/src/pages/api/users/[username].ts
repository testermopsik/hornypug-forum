import type { NextApiRequest, NextApiResponse } from 'next'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') return res.status(405).end()
  const { username } = req.query as { username: string }

  const db = supabaseAdmin()
  const { data } = await db
    .from('users')
    .select('id, username, role, avatar_color, reputation, bio, created_at')
    .ilike('username', username)
    .single()

  if (!data) return res.status(404).json({ error: 'Not found' })
  return res.status(200).json(data)
}
