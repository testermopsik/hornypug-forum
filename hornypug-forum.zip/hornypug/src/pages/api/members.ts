import type { NextApiRequest, NextApiResponse } from 'next'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') return res.status(405).end()
  const db = supabaseAdmin()
  const { search = '', sort = 'rep' } = req.query

  let query = db
    .from('users')
    .select('id, username, role, avatar_color, reputation, created_at')
    .eq('is_banned', false)

  if (search) query = query.ilike('username', `%${search}%`)
  if (sort === 'rep') query = query.order('reputation', { ascending: false })
  else query = query.order('created_at', { ascending: false })

  query = query.limit(60)

  const { data } = await query
  return res.status(200).json({ members: data || [] })
}
