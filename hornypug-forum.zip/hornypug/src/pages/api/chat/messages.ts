import type { NextApiRequest, NextApiResponse } from 'next'
import { parse } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const db = supabaseAdmin()

  if (req.method === 'GET') {
    const { data } = await db
      .from('chat_messages')
      .select('id, body, created_at, users!chat_messages_user_id_fkey(id, username, avatar_color, role)')
      .order('created_at', { ascending: false })
      .limit(60)
    return res.status(200).json({ messages: (data || []).reverse() })
  }

  if (req.method === 'POST') {
    const cookies = parse(req.headers.cookie || '')
    const session = await verifyToken(cookies.hp_token || '')
    if (!session) return res.status(401).json({ error: 'Войди' })

    const { body } = req.body
    if (!body?.trim()) return res.status(400).json({ error: 'Пустое сообщение' })
    if (body.length > 500) return res.status(400).json({ error: 'Слишком длинное' })

    const { data: user } = await db.from('users').select('is_banned').eq('id', session.userId).single()
    if (user?.is_banned) return res.status(403).json({ error: 'Заблокирован' })

    const { data: msg } = await db
      .from('chat_messages')
      .insert({ user_id: session.userId, body: body.trim() })
      .select('id, body, created_at, users!chat_messages_user_id_fkey(id, username, avatar_color, role)')
      .single()

    return res.status(200).json({ message: msg })
  }

  return res.status(405).end()
}
