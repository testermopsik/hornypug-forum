import type { NextApiRequest, NextApiResponse } from 'next'
import { parse } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const db = supabaseAdmin()
  const { id } = req.query as { id: string }

  // GET
  if (req.method === 'GET') {
    const { data: post } = await db
      .from('posts')
      .select(`
        id, title, body, is_pinned, is_locked, views, created_at,
        users!posts_user_id_fkey(id, username, avatar_color, role, reputation),
        categories!posts_category_id_fkey(id, name, slug, icon, color),
        reactions(user_id)
      `)
      .eq('id', id)
      .eq('is_deleted', false)
      .single()

    if (!post) return res.status(404).json({ error: 'Пост не найден' })

    // Increment views
    await db.rpc('increment_views', { post_id: id })

    // Get comments
    const { data: comments } = await db
      .from('comments')
      .select(`
        id, body, created_at,
        users!comments_user_id_fkey(id, username, avatar_color, role)
      `)
      .eq('post_id', id)
      .eq('is_deleted', false)
      .order('created_at', { ascending: true })

    return res.status(200).json({ post, comments: comments || [] })
  }

  // DELETE (admin/owner)
  if (req.method === 'DELETE') {
    const cookies = parse(req.headers.cookie || '')
    const session = await verifyToken(cookies.hp_token || '')
    if (!session) return res.status(401).json({ error: 'Войди' })

    const { data: post } = await db.from('posts').select('user_id').eq('id', id).single()
    if (!post) return res.status(404).json({ error: 'Не найден' })

    const isOwner = post.user_id === session.userId
    const isAdmin = ['admin', 'mod'].includes(session.role)
    if (!isOwner && !isAdmin) return res.status(403).json({ error: 'Нет прав' })

    await db.from('posts').update({ is_deleted: true }).eq('id', id)
    return res.status(200).json({ ok: true })
  }

  return res.status(405).end()
}
