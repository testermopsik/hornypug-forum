import type { NextApiRequest, NextApiResponse } from 'next'
import { parse } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const db = supabaseAdmin()

  // GET — list posts
  if (req.method === 'GET') {
    const { category, sort = 'new', page = '1', limit = '20' } = req.query
    const pageNum = Math.max(1, parseInt(page as string))
    const limitNum = Math.min(50, parseInt(limit as string))
    const from = (pageNum - 1) * limitNum

    let query = db
      .from('posts')
      .select(`
        id, title, body, is_pinned, is_locked, views, created_at,
        user_id,
        users!posts_user_id_fkey(id, username, avatar_color, role),
        categories!posts_category_id_fkey(id, name, slug, icon, color),
        reactions(count),
        comments(count)
      `, { count: 'exact' })
      .eq('is_deleted', false)
      .range(from, from + limitNum - 1)

    if (category) query = query.eq('categories.slug', category)
    if (sort === 'top') query = query.order('views', { ascending: false })
    else query = query.order('is_pinned', { ascending: false }).order('created_at', { ascending: false })

    const { data, error, count } = await query
    if (error) return res.status(500).json({ error: error.message })
    return res.status(200).json({ posts: data, total: count, page: pageNum })
  }

  // POST — create post
  if (req.method === 'POST') {
    const cookies = parse(req.headers.cookie || '')
    const session = await verifyToken(cookies.hp_token || '')
    if (!session) return res.status(401).json({ error: 'Войди в аккаунт' })

    const { title, body, category_id } = req.body
    if (!title?.trim() || !body?.trim() || !category_id)
      return res.status(400).json({ error: 'Заполни все поля' })
    if (title.length > 150) return res.status(400).json({ error: 'Заголовок слишком длинный' })
    if (body.length > 10000) return res.status(400).json({ error: 'Текст слишком длинный' })

    const { data: user } = await db.from('users').select('is_banned').eq('id', session.userId).single()
    if (user?.is_banned) return res.status(403).json({ error: 'Аккаунт заблокирован' })

    const { data, error } = await db
      .from('posts')
      .insert({ title: title.trim(), body: body.trim(), category_id, user_id: session.userId })
      .select('id')
      .single()

    if (error) return res.status(500).json({ error: error.message })

    // Update reputation
    await db.rpc('update_reputation', { uid: session.userId, delta: 10 })

    return res.status(200).json({ post: data })
  }

  return res.status(405).end()
}
