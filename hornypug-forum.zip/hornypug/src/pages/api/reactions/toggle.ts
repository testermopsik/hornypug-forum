import type { NextApiRequest, NextApiResponse } from 'next'
import { parse } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  const db = supabaseAdmin()
  const cookies = parse(req.headers.cookie || '')
  const session = await verifyToken(cookies.hp_token || '')
  if (!session) return res.status(401).json({ error: 'Войди' })

  const { post_id } = req.body
  if (!post_id) return res.status(400).end()

  const { data: existing } = await db
    .from('reactions')
    .select('id')
    .eq('user_id', session.userId)
    .eq('post_id', post_id)
    .single()

  if (existing) {
    await db.from('reactions').delete().eq('id', existing.id)
    return res.status(200).json({ liked: false })
  } else {
    await db.from('reactions').insert({ user_id: session.userId, post_id })
    return res.status(200).json({ liked: true })
  }
}
