import type { NextApiRequest, NextApiResponse } from 'next'
import bcrypt from 'bcryptjs'
import { supabaseAdmin } from '@/lib/supabase'
import { signToken, setAuthCookie } from '@/lib/auth'
import { serialize } from 'cookie'

// Brute force protection (in-memory, resets on deploy — OK for MVP)
const attempts: Record<string, { count: number; time: number }> = {}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  const { username, password } = req.body
  if (!username || !password) return res.status(400).json({ error: 'Заполни все поля' })

  // Rate limiting
  const ip = (req.headers['x-forwarded-for'] as string)?.split(',')[0] || req.socket.remoteAddress || ''
  const key = ip + '_' + username.toLowerCase()
  const now = Date.now()
  if (attempts[key]) {
    if (now - attempts[key].time > 15 * 60 * 1000) delete attempts[key] // reset after 15 min
    else if (attempts[key].count >= 10)
      return res.status(429).json({ error: 'Слишком много попыток. Подожди 15 минут.' })
  }

  const db = supabaseAdmin()

  const { data: user } = await db
    .from('users')
    .select('id, username, password, role, avatar_color, is_banned, ban_reason')
    .ilike('username', username)
    .single()

  if (!user || !(await bcrypt.compare(password, user.password))) {
    attempts[key] = { count: (attempts[key]?.count || 0) + 1, time: now }
    return res.status(401).json({ error: 'Неверный ник или пароль' })
  }

  if (user.is_banned)
    return res.status(403).json({ error: `❌ Аккаунт заблокирован. Причина: ${user.ban_reason || 'нарушение правил'}` })

  // Reset attempts on success
  delete attempts[key]

  // Update last_seen
  await db.from('users').update({ last_seen: new Date().toISOString() }).eq('id', user.id)

  const token = await signToken({ userId: user.id, username: user.username, role: user.role })
  const cookie = setAuthCookie(token)
  res.setHeader('Set-Cookie', serialize(cookie.name, cookie.value, cookie))
  return res.status(200).json({ ok: true, user: { userId: user.id, username: user.username, role: user.role } })
}
