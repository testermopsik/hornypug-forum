import type { NextApiRequest, NextApiResponse } from 'next'
import bcrypt from 'bcryptjs'
import { supabaseAdmin } from '@/lib/supabase'
import { signToken, setAuthCookie } from '@/lib/auth'
import { serialize } from 'cookie'

const COLORS = [
  '#f97316','#fb923c','#f59e0b','#10b981',
  '#38bdf8','#818cf8','#e879f9','#f43f5e',
]

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  const { username, password } = req.body

  // Validation
  if (!username || !password)
    return res.status(400).json({ error: 'Заполни все поля' })
  if (!/^[a-zA-Zа-яёА-ЯЁ0-9_]{3,20}$/.test(username))
    return res.status(400).json({ error: 'Ник: 3–20 символов, буквы/цифры/_' })
  if (password.length < 6)
    return res.status(400).json({ error: 'Пароль минимум 6 символов' })

  const db = supabaseAdmin()

  // Check registration open
  const { data: setting } = await db
    .from('site_settings')
    .select('value')
    .eq('key', 'allow_registration')
    .single()
  if (setting?.value === 'false')
    return res.status(403).json({ error: 'Регистрация временно закрыта' })

  // Check username taken
  const { data: existing } = await db
    .from('users')
    .select('id')
    .ilike('username', username)
    .single()
  if (existing)
    return res.status(400).json({ error: 'Этот ник уже занят' })

  // Hash password
  const hash = await bcrypt.hash(password, 12)
  const color = COLORS[Math.floor(Math.random() * COLORS.length)]

  // Create user
  const { data: user, error } = await db
    .from('users')
    .insert({ username, password: hash, avatar_color: color, role: 'user' })
    .select('id, username, role, avatar_color')
    .single()

  if (error || !user)
    return res.status(500).json({ error: 'Ошибка сервера' })

  // Issue JWT
  const token = await signToken({
    userId: user.id,
    username: user.username,
    role: user.role,
  })

  const cookie = setAuthCookie(token)
  res.setHeader('Set-Cookie', serialize(cookie.name, cookie.value, cookie))
  return res.status(200).json({ ok: true, user: { userId: user.id, username: user.username, role: user.role } })
}
