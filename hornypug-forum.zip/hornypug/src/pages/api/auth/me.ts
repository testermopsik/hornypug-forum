import type { NextApiRequest, NextApiResponse } from 'next'
import { parse } from 'cookie'
import { verifyToken } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const cookies = parse(req.headers.cookie || '')
  const token = cookies.hp_token
  if (!token) return res.status(200).json({ user: null })

  const payload = await verifyToken(token)
  if (!payload) return res.status(200).json({ user: null })

  // Verify user still exists and not banned
  const db = supabaseAdmin()
  const { data: user } = await db
    .from('users')
    .select('id, username, role, avatar_color, is_banned')
    .eq('id', payload.userId)
    .single()

  if (!user || user.is_banned) return res.status(200).json({ user: null })

  return res.status(200).json({
    user: {
      userId: user.id,
      username: user.username,
      role: user.role,
      avatar_color: user.avatar_color,
    }
  })
}
