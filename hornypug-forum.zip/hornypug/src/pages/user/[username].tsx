import { GetServerSideProps } from 'next'
import Head from 'next/head'
import Link from 'next/link'
import Navbar from '@/components/Navbar'
import { supabaseAdmin } from '@/lib/supabase'
import { getSession } from '@/lib/auth'
import styles from './user.module.css'

interface UserProfile {
  id: string; username: string; role: string; avatar_color: string
  reputation: number; bio: string; created_at: string; last_seen: string
  is_banned: boolean
}
interface Post { id: string; title: string; created_at: string; views: number }

interface Props {
  profile: UserProfile
  posts: Post[]
  postCount: number
  likesReceived: number
  session: { userId: string; username: string; role: string } | null
}

export default function UserProfile({ profile, posts, postCount, likesReceived, session }: Props) {
  const initials = (n: string) => n.slice(0, 2).toUpperCase()
  const joinDate = new Date(profile.created_at).toLocaleDateString('ru', { day: 'numeric', month: 'long', year: 'numeric' })
  const lastSeen = new Date(profile.last_seen).toLocaleDateString('ru', { day: 'numeric', month: 'short' })

  const roleLabel: Record<string, string> = { admin: '👑 Администратор', mod: '🛡️ Модератор', user: '' }
  const roleBadge: Record<string, string> = { admin: 'badge-admin', mod: 'badge-mod', user: 'badge-user' }

  return (
    <>
      <Head><title>{profile.username} — Horny Pug</title></Head>
      <Navbar />
      <div className={`container ${styles.page}`}>
        {/* Profile card */}
        <div className={styles.profileCard}>
          <div className={styles.banner} />
          <div className={styles.profileBody}>
            <div className={`avatar avatar-xl ${styles.profileAvatar}`} style={{ background: profile.avatar_color }}>
              {initials(profile.username)}
            </div>
            <div className={styles.profileInfo}>
              <div className={styles.profileName}>
                {profile.username}
                {profile.is_banned && <span className="badge badge-banned">🚫 Заблокирован</span>}
              </div>
              {roleLabel[profile.role] && (
                <span className={`badge ${roleBadge[profile.role]}`}>{roleLabel[profile.role]}</span>
              )}
              {profile.bio && <p className={styles.bio}>{profile.bio}</p>}
              <div className={styles.profileMeta}>
                <span>📅 На сайте с {joinDate}</span>
                <span>👁️ Был: {lastSeen}</span>
              </div>
            </div>
            {session?.role === 'admin' && session.userId !== profile.id && (
              <div className={styles.adminActions}>
                <span className="text-xs text-muted">Действия адм.</span>
                <a href={`/admin?user=${profile.id}`} className="btn btn-sm btn-ghost">⚙️ Управление</a>
              </div>
            )}
          </div>
          <div className={styles.statsRow}>
            <div className={styles.statItem}>
              <div className={styles.statNum}>{postCount}</div>
              <div className={styles.statLabel}>Постов</div>
            </div>
            <div className={styles.statDiv} />
            <div className={styles.statItem}>
              <div className={styles.statNum}>{likesReceived}</div>
              <div className={styles.statLabel}>Лайков получено</div>
            </div>
            <div className={styles.statDiv} />
            <div className={styles.statItem}>
              <div className={styles.statNum} style={{ color: 'var(--accent)' }}>⭐ {profile.reputation.toLocaleString('ru')}</div>
              <div className={styles.statLabel}>Репутация</div>
            </div>
          </div>
        </div>

        {/* Posts */}
        <div className={styles.postsSection}>
          <h2 className={styles.sectionTitle}>Посты пользователя</h2>
          {posts.length === 0 ? (
            <div className={styles.empty}>
              <div>📭</div>
              <p>Пока нет постов</p>
            </div>
          ) : (
            <div className={styles.postsList}>
              {posts.map(p => (
                <Link key={p.id} href={`/post/${p.id}`} className={styles.postRow}>
                  <div className={styles.postRowTitle}>{p.title}</div>
                  <div className={styles.postRowMeta}>
                    <span>👁️ {p.views}</span>
                    <span>{new Date(p.created_at).toLocaleDateString('ru')}</span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  )
}

export const getServerSideProps: GetServerSideProps = async (ctx) => {
  const { username } = ctx.params as { username: string }
  const session = await getSession()
  const db = supabaseAdmin()

  const { data: profile } = await db
    .from('users')
    .select('id, username, role, avatar_color, reputation, bio, created_at, last_seen, is_banned')
    .ilike('username', username)
    .single()

  if (!profile) return { notFound: true }

  const [postsRes, reactionsRes] = await Promise.all([
    db.from('posts').select('id, title, created_at, views').eq('user_id', profile.id).eq('is_deleted', false).order('created_at', { ascending: false }).limit(20),
    db.from('reactions').select('id', { count: 'exact', head: true }).in('post_id',
      (await db.from('posts').select('id').eq('user_id', profile.id)).data?.map(p => p.id) || ['__none__']
    ),
  ])

  return {
    props: {
      profile,
      posts: postsRes.data || [],
      postCount: postsRes.data?.length || 0,
      likesReceived: reactionsRes.count || 0,
      session: session ? { userId: session.userId, username: session.username, role: session.role } : null,
    }
  }
}
