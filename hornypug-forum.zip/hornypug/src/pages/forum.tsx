import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/router'
import Link from 'next/link'
import Head from 'next/head'
import Navbar from '@/components/Navbar'
import styles from './forum.module.css'

interface Post {
  id: string
  title: string
  body: string
  is_pinned: boolean
  is_locked: boolean
  views: number
  created_at: string
  users: { id: string; username: string; avatar_color: string; role: string } | null
  categories: { id: number; name: string; slug: string; icon: string; color: string } | null
  reactions: { count: number }[]
  comments: { count: number }[]
}

interface Category {
  id: number; name: string; slug: string; icon: string; color: string
}

export default function Forum() {
  const router = useRouter()
  const { cat: catParam } = router.query
  const [posts, setPosts] = useState<Post[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [sort, setSort] = useState<'new'|'top'>('new')
  const [showCompose, setShowCompose] = useState(false)
  const [form, setForm] = useState({ title: '', body: '', category_id: '' })
  const [submitting, setSubmitting] = useState(false)
  const [user, setUser] = useState<{username:string; role:string} | null>(null)
  const [error, setError] = useState('')

  const fetchPosts = useCallback(async () => {
    setLoading(true)
    const params = new URLSearchParams({ sort })
    if (catParam) params.append('category', catParam as string)
    const r = await fetch(`/api/posts?${params}`)
    const d = await r.json()
    setPosts(d.posts || [])
    setLoading(false)
  }, [sort, catParam])

  useEffect(() => {
    fetchPosts()
    fetch('/api/auth/me').then(r => r.json()).then(d => setUser(d.user))
    fetch('/api/admin/manage?type=categories').then(r => r.json()).then(d => setCategories(d.categories || []))
  }, [fetchPosts])

  const submit = async () => {
    if (!form.title.trim() || !form.body.trim() || !form.category_id) return setError('Заполни все поля')
    setError(''); setSubmitting(true)
    const r = await fetch('/api/posts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    const d = await r.json()
    setSubmitting(false)
    if (!r.ok) { setError(d.error); return }
    setShowCompose(false)
    setForm({ title: '', body: '', category_id: '' })
    fetchPosts()
    router.push(`/post/${d.post.id}`)
  }

  const initials = (n: string) => n.slice(0, 2).toUpperCase()
  const timeAgo = (ts: string) => {
    const d = Date.now() - new Date(ts).getTime()
    if (d < 60000) return 'только что'
    if (d < 3600000) return `${Math.floor(d/60000)} мин назад`
    if (d < 86400000) return `${Math.floor(d/3600000)} ч назад`
    return `${Math.floor(d/86400000)} дн назад`
  }

  const activeCat = catParam as string | undefined

  return (
    <>
      <Head><title>Форум — Horny Pug</title></Head>
      <Navbar />
      <div className="container" style={{ paddingTop: 32, paddingBottom: 80 }}>
        <div className={styles.layout}>

          {/* Sidebar */}
          <aside className={`${styles.sidebar} hide-mobile`}>
            <div className="card">
              <div className="card-body" style={{ padding: 12 }}>
                <Link href="/forum" className={`${styles.catLink} ${!activeCat ? styles.catLinkActive : ''}`}>
                  🏠 Все разделы
                </Link>
                {categories.map(c => (
                  <Link
                    key={c.id}
                    href={`/forum?cat=${c.slug}`}
                    className={`${styles.catLink} ${activeCat === c.slug ? styles.catLinkActive : ''}`}
                    style={activeCat === c.slug ? { color: c.color, background: c.color+'15' } : {}}
                  >
                    <span>{c.icon}</span> {c.name}
                  </Link>
                ))}
              </div>
            </div>
            <div className="card" style={{ marginTop: 16 }}>
              <div className="card-body">
                <p style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 1.6 }}>
                  💬 <strong>Живой чат</strong> — общайся в реальном времени
                </p>
                <Link href="/chat" className="btn btn-ghost w-full" style={{ justifyContent: 'center', marginTop: 12 }}>
                  Открыть чат →
                </Link>
              </div>
            </div>
          </aside>

          {/* Main */}
          <main className={styles.main}>
            <div className={styles.header}>
              <h1 className={styles.title}>
                {activeCat ? categories.find(c => c.slug === activeCat)?.name || 'Форум' : 'Форум'}
              </h1>
              <div className={styles.headerRight}>
                <div className={styles.sortBtns}>
                  <button className={`${styles.sortBtn} ${sort==='new' ? styles.sortActive:''}`} onClick={() => setSort('new')}>⚡ Новые</button>
                  <button className={`${styles.sortBtn} ${sort==='top' ? styles.sortActive:''}`} onClick={() => setSort('top')}>🔥 Топ</button>
                </div>
                {user && (
                  <button className="btn btn-primary btn-sm" onClick={() => setShowCompose(!showCompose)}>
                    + Написать
                  </button>
                )}
              </div>
            </div>

            {/* Compose box */}
            {showCompose && (
              <div className={`card ${styles.composeCard}`}>
                <div className="card-body">
                  <h3 className={styles.composeTitle}>Новый пост</h3>
                  {error && <div className="alert alert-error">{error}</div>}
                  <div className="field">
                    <label className="input-label">Заголовок</label>
                    <input className="input" placeholder="Кратко о чём пост..." value={form.title} onChange={e => setForm({...form, title: e.target.value})} maxLength={150} />
                  </div>
                  <div className="field">
                    <label className="input-label">Раздел</label>
                    <select className="input" value={form.category_id} onChange={e => setForm({...form, category_id: e.target.value})}>
                      <option value="">Выбери раздел...</option>
                      {categories.map(c => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
                    </select>
                  </div>
                  <div className="field">
                    <label className="input-label">Текст</label>
                    <textarea className="input" placeholder="Расскажи подробнее..." rows={5} value={form.body} onChange={e => setForm({...form, body: e.target.value})} />
                  </div>
                  <div className={styles.composeActions}>
                    <button className="btn btn-ghost btn-sm" onClick={() => setShowCompose(false)}>Отмена</button>
                    <button className="btn btn-primary btn-sm" onClick={submit} disabled={submitting}>
                      {submitting ? '⟳' : '📤 Опубликовать'}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Posts */}
            {loading ? (
              <div className={styles.skeletons}>
                {[...Array(5)].map((_, i) => <div key={i} className={`skeleton ${styles.skeletonPost}`} />)}
              </div>
            ) : posts.length === 0 ? (
              <div className={styles.empty}>
                <div className={styles.emptyIcon}>🐾</div>
                <p>Постов пока нет. Стань первым!</p>
                {user && <button className="btn btn-primary" style={{marginTop:16}} onClick={() => setShowCompose(true)}>+ Написать пост</button>}
              </div>
            ) : (
              <div className={styles.posts}>
                {posts.map((post, i) => (
                  <Link key={post.id} href={`/post/${post.id}`} className={styles.postCard} style={{ animationDelay: `${i * 0.04}s` }}>
                    {post.is_pinned && <div className={styles.pinnedBadge}>📌 Закреплён</div>}
                    <div className={styles.postMeta}>
                      <div
                        className="avatar avatar-md"
                        style={{ background: post.users?.avatar_color || '#f97316' }}
                      >
                        {initials(post.users?.username || '?')}
                      </div>
                      <div className={styles.postInfo}>
                        <div className={styles.postAuthor}>
                          {post.users?.username || 'Удалён'}
                          {post.users?.role === 'admin' && <span className="badge badge-admin">👑 Admin</span>}
                          {post.users?.role === 'mod' && <span className="badge badge-mod">🛡️ Mod</span>}
                        </div>
                        <div className={styles.postTime}>{timeAgo(post.created_at)}</div>
                      </div>
                      {post.categories && (
                        <div
                          className={styles.postCat}
                          style={{ background: post.categories.color + '18', color: post.categories.color, border: `1px solid ${post.categories.color}30` }}
                        >
                          {post.categories.icon} {post.categories.name}
                        </div>
                      )}
                    </div>
                    <div className={styles.postTitle}>{post.title}</div>
                    <div className={styles.postBody}>{post.body.slice(0, 160)}{post.body.length > 160 ? '...' : ''}</div>
                    <div className={styles.postFooter}>
                      <span className={styles.postStat}>❤️ {Array.isArray(post.reactions) ? post.reactions[0]?.count || 0 : 0}</span>
                      <span className={styles.postStat}>💬 {Array.isArray(post.comments) ? post.comments[0]?.count || 0 : 0}</span>
                      <span className={styles.postStat}>👁️ {post.views}</span>
                      {post.is_locked && <span className={styles.postStat}>🔒 Закрыт</span>}
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </main>
        </div>
      </div>
    </>
  )
}
