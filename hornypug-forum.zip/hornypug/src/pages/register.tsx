import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/router'
import Head from 'next/head'
import styles from './auth.module.css'

export default function Register() {
  const router = useRouter()
  const [form, setForm] = useState({ username: '', password: '', confirm: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [nickStatus, setNickStatus] = useState<'idle'|'ok'|'bad'>('idle')
  const [strength, setStrength] = useState(0)

  const checkNick = (v: string) => {
    if (!v) return setNickStatus('idle')
    setNickStatus(/^[a-zA-Zа-яёА-ЯЁ0-9_]{3,20}$/.test(v) ? 'ok' : 'bad')
  }

  const calcStrength = (p: string) => {
    let s = 0
    if (p.length >= 6) s++
    if (p.length >= 10) s++
    if (/[A-Z]|[А-ЯЁ]/.test(p)) s++
    if (/[0-9]/.test(p)) s++
    if (/[^a-zA-Zа-яёА-ЯЁ0-9]/.test(p)) s++
    setStrength(s)
  }

  const submit = async () => {
    setError('')
    if (form.password !== form.confirm) return setError('Пароли не совпадают')
    setLoading(true)
    const r = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: form.username, password: form.password }),
    })
    const d = await r.json()
    setLoading(false)
    if (!r.ok) return setError(d.error)
    router.push('/forum')
  }

  const strengthColors = ['', '#ef4444', '#f97316', '#f59e0b', '#22c55e', '#22c55e']
  const strengthLabels = ['', 'Слабый', 'Нормальный', 'Хороший', 'Сильный', 'Отличный!']

  return (
    <>
      <Head><title>Регистрация — Horny Pug</title></Head>
      <div className={styles.page}>
        <div className={styles.bg}><div className={styles.orb1}/><div className={styles.orb2}/></div>
        <div className={styles.card}>
          <Link href="/" className={styles.logo}>🐾 Horny<span>Pug</span></Link>
          <h1 className={styles.title}>Создать аккаунт</h1>
          <p className={styles.sub}>Только ник и пароль. Никаких email.</p>

          {error && <div className="alert alert-error">{error}</div>}

          <div className="field">
            <label className="input-label">
              Никнейм
              {nickStatus === 'ok' && <span style={{color:'var(--green)',marginLeft:8}}>✓ Свободен</span>}
              {nickStatus === 'bad' && <span style={{color:'var(--red)',marginLeft:8}}>✗ Недопустимый</span>}
            </label>
            <input
              className="input"
              placeholder="придумай уникальный ник"
              maxLength={20}
              value={form.username}
              onChange={e => { setForm({...form, username: e.target.value}); checkNick(e.target.value) }}
              onKeyDown={e => e.key === 'Enter' && submit()}
            />
            <p style={{fontSize:12,color:'var(--text3)',marginTop:5}}>3–20 символов: буквы, цифры, _</p>
          </div>

          <div className="field">
            <label className="input-label">Пароль</label>
            <input
              className="input" type="password" placeholder="минимум 6 символов"
              value={form.password}
              onChange={e => { setForm({...form, password: e.target.value}); calcStrength(e.target.value) }}
            />
            <div className={styles.strengthBar}>
              <div className={styles.strengthFill} style={{ width: `${strength*20}%`, background: strengthColors[strength] }} />
            </div>
            {form.password && <p style={{fontSize:12,color:strengthColors[strength],marginTop:4}}>{strengthLabels[strength]}</p>}
          </div>

          <div className="field">
            <label className="input-label">Повторить пароль</label>
            <input
              className="input" type="password" placeholder="повтори пароль"
              value={form.confirm}
              onChange={e => setForm({...form, confirm: e.target.value})}
              onKeyDown={e => e.key === 'Enter' && submit()}
            />
            {form.confirm && form.confirm !== form.password && (
              <p style={{fontSize:12,color:'var(--red)',marginTop:4}}>✗ Пароли не совпадают</p>
            )}
          </div>

          <button className={`btn btn-primary w-full ${styles.submitBtn}`} onClick={submit} disabled={loading}>
            {loading ? <span className="spinner">⟳</span> : 'Создать аккаунт →'}
          </button>

          <p className={styles.switch}>Уже есть аккаунт? <Link href="/login">Войти</Link></p>
        </div>
      </div>
    </>
  )
}
