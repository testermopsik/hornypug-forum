import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/router'
import Head from 'next/head'
import styles from './auth.module.css'

export default function Login() {
  const router = useRouter()
  const [form, setForm] = useState({ username: '', password: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const submit = async () => {
    setError('')
    if (!form.username || !form.password) return setError('Заполни все поля')
    setLoading(true)
    const r = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    const d = await r.json()
    setLoading(false)
    if (!r.ok) return setError(d.error)
    router.push('/forum')
  }

  return (
    <>
      <Head><title>Вход — Horny Pug</title></Head>
      <div className={styles.page}>
        <div className={styles.bg}><div className={styles.orb1}/><div className={styles.orb2}/></div>
        <div className={styles.card}>
          <Link href="/" className={styles.logo}>🐾 Horny<span>Pug</span></Link>
          <h1 className={styles.title}>Добро пожаловать!</h1>
          <p className={styles.sub}>Войди в свой аккаунт</p>

          {error && <div className="alert alert-error">{error}</div>}

          <div className="field">
            <label className="input-label">Никнейм</label>
            <input
              className="input" placeholder="твой никнейм"
              value={form.username}
              onChange={e => setForm({...form, username: e.target.value})}
              onKeyDown={e => e.key === 'Enter' && submit()}
            />
          </div>

          <div className="field">
            <label className="input-label">Пароль</label>
            <input
              className="input" type="password" placeholder="твой пароль"
              value={form.password}
              onChange={e => setForm({...form, password: e.target.value})}
              onKeyDown={e => e.key === 'Enter' && submit()}
            />
          </div>

          <button className={`btn btn-primary w-full ${styles.submitBtn}`} onClick={submit} disabled={loading}>
            {loading ? <span className="spinner">⟳</span> : 'Войти →'}
          </button>

          <p className={styles.switch}>Нет аккаунта? <Link href="/register">Зарегистрироваться</Link></p>
        </div>
      </div>
    </>
  )
}
