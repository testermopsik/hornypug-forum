import { GetServerSideProps } from 'next'
import Link from 'next/link'
import Head from 'next/head'
import Navbar from '@/components/Navbar'
import { supabaseAdmin } from '@/lib/supabase'
import styles from './index.module.css'

interface Props {
  stats: { users: number; posts: number; online: number }
  categories: Array<{ id: number; name: string; slug: string; icon: string; color: string; description: string; post_count: number }>
  announcements: Array<{ id: number; title: string; body: string; created_at: string }>
  recentPosts: Array<{ id: string; title: string; created_at: string; users: { username: string; avatar_color: string } | null; categories: { name: string; icon: string } | null }>
}

export default function Home({ stats, categories, announcements, recentPosts }: Props) {
  return (
    <>
      <Head><title>Horny Pug — Форум сообщества</title></Head>
      <div className={styles.page}>
        <Navbar />

        {/* Hero */}
        <div className={styles.hero}>
          <div className={styles.heroBg}>
            <div className={styles.heroOrb1} />
            <div className={styles.heroOrb2} />
            <div className={styles.heroGrid} />
          </div>
          <div className="container">
            <div className={styles.heroContent}>
              <div className={styles.eyebrow}>
                <span>🐾</span> Добро пожаловать
              </div>
              <h1 className={styles.heroTitle}>
                Horny<span className={styles.heroAccent}>Pug</span>
              </h1>
              <p className={styles.heroSub}>
                Лучший форум сообщества. Общайся, спорь, дружи — без лишних вопросов.
              </p>
              <div className={styles.heroCta}>
                <Link href="/register" className="btn btn-primary">🚀 Присоединиться</Link>
                <Link href="/forum" className="btn btn-ghost">Смотреть форум</Link>
              </div>
              <div className={styles.heroStats}>
                <div className={styles.heroStat}>
                  <span className={styles.heroStatNum}>{stats.users.toLocaleString('ru')}</span>
                  <span className={styles.heroStatLabel}>Участников</span>
                </div>
                <div className={styles.heroStatDivider} />
                <div className={styles.heroStat}>
                  <span className={styles.heroStatNum}>{stats.posts.toLocaleString('ru')}</span>
                  <span className={styles.heroStatLabel}>Постов</span>
                </div>
                <div className={styles.heroStatDivider} />
                <div className={styles.heroStat}>
                  <span className={styles.heroStatNum}>{stats.online}</span>
                  <span className={styles.heroStatLabel}>Онлайн</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="container">
          <div className={styles.layout}>
            {/* Main */}
            <div className={styles.main}>

              {/* Announcements */}
              {announcements.length > 0 && (
                <div className={styles.announcements}>
                  {announcements.map(a => (
                    <div key={a.id} className={styles.announce}>
                      <div className={styles.announceIcon}>📢</div>
                      <div>
                        <div className={styles.announceTitle}>{a.title}</div>
                        <div className={styles.announceBody}>{a.body}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Categories */}
              <div className={styles.sectionHeader}>
                <h2 className={styles.sectionTitle}>Разделы форума</h2>
                <Link href="/forum" className={`btn btn-ghost btn-sm`}>Все посты →</Link>
              </div>
              <div className={styles.categories}>
                {categories.map(cat => (
                  <Link key={cat.id} href={`/forum?cat=${cat.slug}`} className={styles.catCard}>
                    <div className={styles.catIcon} style={{ background: cat.color + '20', border: `1px solid ${cat.color}40` }}>
                      {cat.icon}
                    </div>
                    <div className={styles.catInfo}>
                      <div className={styles.catName}>{cat.name}</div>
                      <div className={styles.catDesc}>{cat.description}</div>
                    </div>
                    <div className={styles.catCount} style={{ color: cat.color }}>
                      {cat.post_count}
                    </div>
                  </Link>
                ))}
              </div>

              {/* Recent Posts */}
              <div className={styles.sectionHeader} style={{ marginTop: 40 }}>
                <h2 className={styles.sectionTitle}>Последние посты</h2>
              </div>
              <div className={styles.recentPosts}>
                {recentPosts.map(post => (
                  <Link key={post.id} href={`/post/${post.id}`} className={styles.recentPost}>
                    <div
                      className="avatar avatar-sm"
                      style={{ background: post.users?.avatar_color || '#f97316', flexShrink: 0 }}
                    >
                      {(post.users?.username || '?').slice(0, 2).toUpperCase()}
                    </div>
                    <div className={styles.recentInfo}>
                      <div className={styles.recentTitle}>{post.title}</div>
                      <div className={styles.recentMeta}>
                        <span>{post.users?.username || 'Удалён'}</span>
                        <span>·</span>
                        <span>{post.categories?.icon} {post.categories?.name}</span>
                        <span>·</span>
                        <span>{new Date(post.created_at).toLocaleDateString('ru')}</span>
                      </div>
                    </div>
                    <span className={styles.recentArrow}>→</span>
                  </Link>
                ))}
              </div>
            </div>

            {/* Sidebar */}
            <aside className={styles.sidebar}>
              <div className="card">
                <div className="card-body">
                  <h3 className={styles.widgetTitle}>🚀 Начать</h3>
                  <p style={{ color: 'var(--text2)', fontSize: 13, marginBottom: 16, lineHeight: 1.5 }}>
                    Зарегистрируйся и стань частью сообщества. Только ник и пароль — никакого email.
                  </p>
                  <Link href="/register" className="btn btn-primary w-full" style={{ justifyContent: 'center' }}>
                    Регистрация →
                  </Link>
                  <Link href="/login" className="btn btn-ghost w-full mt-4" style={{ justifyContent: 'center' }}>
                    Уже есть аккаунт
                  </Link>
                </div>
              </div>

              <div className="card mt-4">
                <div className="card-body">
                  <h3 className={styles.widgetTitle}>💬 Живой чат</h3>
                  <p style={{ color: 'var(--text2)', fontSize: 13, marginBottom: 16 }}>
                    Общайся с другими участниками в реальном времени.
                  </p>
                  <Link href="/chat" className="btn btn-ghost w-full" style={{ justifyContent: 'center' }}>
                    Открыть чат →
                  </Link>
                </div>
              </div>

              <div className="card mt-4">
                <div className="card-body">
                  <h3 className={styles.widgetTitle}>📜 Правила</h3>
                  <ul style={{ color: 'var(--text2)', fontSize: 13, paddingLeft: 16, lineHeight: 2 }}>
                    <li>Уважай других участников</li>
                    <li>Не спамь и не флудь</li>
                    <li>Пиши в нужном разделе</li>
                    <li>Никаких угроз и оскорблений</li>
                    <li>Решение модераторов — финально</li>
                  </ul>
                </div>
              </div>
            </aside>
          </div>
        </div>

        <footer className={styles.footer}>
          <div className="container">
            <div className={styles.footerInner}>
              <span className={styles.footerLogo}>🐾 HornyPug</span>
              <span style={{ color: 'var(--text3)', fontSize: 13 }}>© 2024 Все права защищены</span>
            </div>
          </div>
        </footer>
      </div>
    </>
  )
}

export const getServerSideProps: GetServerSideProps = async () => {
  const db = supabaseAdmin()
  const [
    { count: users },
    { count: posts },
    { data: categories },
    { data: announcements },
    { data: recentPosts },
  ] = await Promise.all([
    db.from('users').select('*', { count: 'exact', head: true }),
    db.from('posts').select('*', { count: 'exact', head: true }).eq('is_deleted', false),
    db.from('categories').select('*').order('sort_order'),
    db.from('announcements').select('*').eq('is_active', true).order('created_at', { ascending: false }).limit(3),
    db.from('posts')
      .select('id, title, created_at, users!posts_user_id_fkey(username, avatar_color), categories!posts_category_id_fkey(name, icon)')
      .eq('is_deleted', false)
      .order('created_at', { ascending: false })
      .limit(8),
  ])

  return {
    props: {
      stats: { users: users || 0, posts: posts || 0, online: Math.floor(Math.random() * 40) + 5 },
      categories: categories || [],
      announcements: announcements || [],
      recentPosts: recentPosts || [],
    }
  }
}
