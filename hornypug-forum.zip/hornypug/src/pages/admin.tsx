import { useState, useEffect, useCallback } from 'react'
import { GetServerSideProps } from 'next'
import Head from 'next/head'
import Link from 'next/link'
import Navbar from '@/components/Navbar'
import { getSession } from '@/lib/auth'
import styles from './admin.module.css'

type Tab = 'dashboard' | 'users' | 'posts' | 'categories' | 'announcements' | 'settings'

interface Stats { users: number; posts: number; comments: number; banned: number; messages: number }
interface User { id: string; username: string; role: string; avatar_color: string; reputation: number; is_banned: boolean; ban_reason: string; created_at: string }
interface Post { id: string; title: string; is_pinned: boolean; is_locked: boolean; is_deleted: boolean; created_at: string; users: { username: string } | null }
interface Category { id: number; name: string; slug: string; icon: string; color: string; description: string }
interface Announcement { id: number; title: string; body: string; is_active: boolean; created_at: string }

export default function AdminPanel() {
  const [tab, setTab] = useState<Tab>('dashboard')
  const [stats, setStats] = useState<Stats | null>(null)
  const [users, setUsers] = useState<User[]>([])
  const [posts, setPosts] = useState<Post[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [settings, setSettings] = useState<Record<string, string>>({})
  const [userSearch, setUserSearch] = useState('')
  const [banReason, setBanReason] = useState('')
  const [newCat, setNewCat] = useState({ name: '', slug: '', description: '', icon: '💬', color: '#f97316' })
  const [newAnnounce, setNewAnnounce] = useState({ title: '', body: '' })
  const [toast, setToast] = useState('')

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000) }

  const load = useCallback(async () => {
    if (tab === 'dashboard') {
      const r = await fetch('/api/admin/manage?type=stats'); const d = await r.json(); setStats(d)
    }
    if (tab === 'users') {
      const r = await fetch(`/api/admin/users?search=${userSearch}`); const d = await r.json(); setUsers(d.users || [])
    }
    if (tab === 'posts') {
      const r = await fetch('/api/admin/manage?type=posts'); const d = await r.json(); setPosts(d.posts || [])
    }
    if (tab === 'categories') {
      const r = await fetch('/api/admin/manage?type=categories'); const d = await r.json(); setCategories(d.categories || [])
    }
    if (tab === 'announcements') {
      const r = await fetch('/api/admin/manage?type=announcements'); const d = await r.json(); setAnnouncements(d.announcements || [])
    }
    if (tab === 'settings') {
      const r = await fetch('/api/admin/manage?type=settings'); const d = await r.json(); setSettings(d.settings || {})
    }
  }, [tab, userSearch])

  useEffect(() => { load() }, [load])

  const banUser = async (userId: string, action: 'ban'|'unban') => {
    await fetch('/api/admin/users', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, action, reason: banReason })
    })
    showToast(action === 'ban' ? '🚫 Пользователь забанен' : '✅ Пользователь разбанен')
    load()
  }

  const changeRole = async (userId: string, role: string) => {
    await fetch('/api/admin/users', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, action: 'role', role })
    })
    showToast('✅ Роль изменена')
    load()
  }

  const deleteUser = async (userId: string) => {
    if (!confirm('Удалить пользователя?')) return
    await fetch('/api/admin/users', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId })
    })
    showToast('🗑️ Пользователь удалён')
    load()
  }

  const postAction = async (postId: string, action: string) => {
    await fetch('/api/admin/manage?type=posts', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ postId, action })
    })
    showToast('✅ Готово')
    load()
  }

  const addCategory = async () => {
    if (!newCat.name || !newCat.slug) return
    const r = await fetch('/api/admin/manage?type=categories', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(newCat)
    })
    if (r.ok) { showToast('✅ Раздел добавлен'); setNewCat({ name: '', slug: '', description: '', icon: '💬', color: '#f97316' }); load() }
    else { const d = await r.json(); showToast('❌ ' + d.error) }
  }

  const deleteCategory = async (id: number) => {
    if (!confirm('Удалить раздел?')) return
    await fetch('/api/admin/manage?type=categories', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) })
    showToast('🗑️ Раздел удалён'); load()
  }

  const addAnnouncement = async () => {
    if (!newAnnounce.title || !newAnnounce.body) return
    await fetch('/api/admin/manage?type=announcements', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(newAnnounce)
    })
    showToast('✅ Объявление добавлено'); setNewAnnounce({ title: '', body: '' }); load()
  }

  const saveSettings = async () => {
    await fetch('/api/admin/manage?type=settings', {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ settings })
    })
    showToast('✅ Настройки сохранены')
  }

  const initials = (n: string) => n.slice(0, 2).toUpperCase()

  return (
    <>
      <Head><title>Панель управления — Horny Pug</title></Head>
      <Navbar />
      <div className={styles.adminPage}>
        {/* Sidebar */}
        <aside className={styles.adminSidebar}>
          <div className={styles.sidebarTitle}>⚙️ УПРАВЛЕНИЕ</div>
          {([
            ['dashboard', '📊', 'Дашборд'],
            ['users', '👥', 'Пользователи'],
            ['posts', '📝', 'Посты'],
            ['categories', '📂', 'Разделы'],
            ['announcements', '📢', 'Объявления'],
            ['settings', '⚙️', 'Настройки'],
          ] as [Tab, string, string][]).map(([t, icon, label]) => (
            <button key={t} className={`${styles.sidebarLink} ${tab === t ? styles.sidebarActive : ''}`} onClick={() => setTab(t)}>
              <span>{icon}</span> {label}
            </button>
          ))}
          <div className={styles.sidebarDivider} />
          <Link href="/" className={styles.sidebarLink}>← На сайт</Link>
        </aside>

        {/* Main */}
        <main className={styles.adminMain}>
          {/* Toast */}
          {toast && <div className={styles.toast}>{toast}</div>}

          {/* ── DASHBOARD ── */}
          {tab === 'dashboard' && stats && (
            <div className="animate-fade-up">
              <div className={styles.pageHeader}>
                <h1 className={styles.pageTitle}>Дашборд</h1>
                <p className={styles.pageSub}>Обзор платформы Horny Pug</p>
              </div>
              <div className={styles.statsGrid}>
                {[
                  { label: 'Пользователей', value: stats.users, icon: '👥', color: '#38bdf8' },
                  { label: 'Постов', value: stats.posts, icon: '📝', color: '#f97316' },
                  { label: 'Комментариев', value: stats.comments, icon: '💬', color: '#a78bfa' },
                  { label: 'Заблокировано', value: stats.banned, icon: '🚫', color: '#ef4444' },
                  { label: 'Сообщений в чате', value: stats.messages, icon: '💬', color: '#22c55e' },
                ].map(s => (
                  <div key={s.label} className={styles.statCard} style={{ borderColor: s.color + '30' }}>
                    <div className={styles.statIcon} style={{ background: s.color + '15', color: s.color }}>{s.icon}</div>
                    <div className={styles.statNum} style={{ color: s.color }}>{s.value}</div>
                    <div className={styles.statLabel}>{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── USERS ── */}
          {tab === 'users' && (
            <div className="animate-fade-up">
              <div className={styles.pageHeader}>
                <h1 className={styles.pageTitle}>Пользователи</h1>
                <input className="input" style={{ width: 240 }} placeholder="🔍 Поиск по нику..." value={userSearch} onChange={e => setUserSearch(e.target.value)} />
              </div>
              <div className={styles.tableWrap}>
                <table className={styles.table}>
                  <thead><tr><th>Пользователь</th><th>Роль</th><th>Репутация</th><th>Статус</th><th>Дата</th><th>Действия</th></tr></thead>
                  <tbody>
                    {users.map(u => (
                      <tr key={u.id}>
                        <td>
                          <div className="flex items-center gap-2">
                            <div className="avatar avatar-sm" style={{ background: u.avatar_color }}>{initials(u.username)}</div>
                            <strong>{u.username}</strong>
                          </div>
                        </td>
                        <td>
                          <select className={styles.roleSelect} value={u.role} onChange={e => changeRole(u.id, e.target.value)}>
                            <option value="user">👤 User</option>
                            <option value="mod">🛡️ Mod</option>
                            <option value="admin">👑 Admin</option>
                          </select>
                        </td>
                        <td>⭐ {u.reputation}</td>
                        <td>
                          <span className={`badge ${u.is_banned ? 'badge-banned' : 'badge-user'}`}>
                            {u.is_banned ? '🚫 Забанен' : '✅ Активен'}
                          </span>
                        </td>
                        <td className="text-sm text-muted">{new Date(u.created_at).toLocaleDateString('ru')}</td>
                        <td>
                          <div className="flex gap-2">
                            {u.is_banned
                              ? <button className="btn btn-sm" style={{ background: 'rgba(34,197,94,0.1)', color: 'var(--green)', border: '1px solid rgba(34,197,94,0.3)' }} onClick={() => banUser(u.id, 'unban')}>✅ Разбанить</button>
                              : <button className="btn btn-danger btn-sm" onClick={() => { const r = prompt('Причина бана (необязательно):') || ''; setBanReason(r); banUser(u.id, 'ban') }}>🚫 Забанить</button>
                            }
                            <button className="btn btn-danger btn-sm" onClick={() => deleteUser(u.id)}>🗑️</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ── POSTS ── */}
          {tab === 'posts' && (
            <div className="animate-fade-up">
              <div className={styles.pageHeader}><h1 className={styles.pageTitle}>Модерация постов</h1></div>
              <div className={styles.tableWrap}>
                <table className={styles.table}>
                  <thead><tr><th>Заголовок</th><th>Автор</th><th>Статус</th><th>Дата</th><th>Действия</th></tr></thead>
                  <tbody>
                    {posts.map(p => (
                      <tr key={p.id} style={{ opacity: p.is_deleted ? 0.5 : 1 }}>
                        <td className="truncate" style={{ maxWidth: 240 }}><Link href={`/post/${p.id}`} style={{ color: 'var(--accent)' }}>{p.title}</Link></td>
                        <td>{p.users?.username || '—'}</td>
                        <td>
                          {p.is_deleted && <span className="badge badge-banned">Удалён</span>}
                          {p.is_pinned && !p.is_deleted && <span className="badge badge-pinned">📌</span>}
                          {p.is_locked && !p.is_deleted && <span className="badge badge-mod">🔒</span>}
                          {!p.is_deleted && !p.is_pinned && !p.is_locked && <span className="badge badge-user">Активен</span>}
                        </td>
                        <td className="text-sm text-muted">{new Date(p.created_at).toLocaleDateString('ru')}</td>
                        <td>
                          <div className="flex gap-2" style={{ flexWrap: 'wrap' }}>
                            {!p.is_deleted && (
                              <>
                                <button className="btn btn-sm btn-ghost" onClick={() => postAction(p.id, p.is_pinned ? 'unpin' : 'pin')}>{p.is_pinned ? '📌 Открепить' : '📌 Закрепить'}</button>
                                <button className="btn btn-sm btn-ghost" onClick={() => postAction(p.id, p.is_locked ? 'unlock' : 'lock')}>{p.is_locked ? '🔓 Открыть' : '🔒 Закрыть'}</button>
                                <button className="btn btn-danger btn-sm" onClick={() => postAction(p.id, 'delete')}>🗑️</button>
                              </>
                            )}
                            {p.is_deleted && <button className="btn btn-sm btn-ghost" onClick={() => postAction(p.id, 'restore')}>♻️ Восстановить</button>}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ── CATEGORIES ── */}
          {tab === 'categories' && (
            <div className="animate-fade-up">
              <div className={styles.pageHeader}><h1 className={styles.pageTitle}>Разделы форума</h1></div>
              <div className={styles.formCard}>
                <h3 className={styles.formTitle}>Добавить раздел</h3>
                <div className={styles.formRow}>
                  <div className="field"><label className="input-label">Название</label><input className="input" placeholder="Мой раздел" value={newCat.name} onChange={e => setNewCat({...newCat, name: e.target.value})} /></div>
                  <div className="field"><label className="input-label">Slug (URL)</label><input className="input" placeholder="my-cat" value={newCat.slug} onChange={e => setNewCat({...newCat, slug: e.target.value.toLowerCase().replace(/\s/g, '-')})} /></div>
                  <div className="field"><label className="input-label">Иконка</label><input className="input" placeholder="💬" value={newCat.icon} onChange={e => setNewCat({...newCat, icon: e.target.value})} /></div>
                  <div className="field"><label className="input-label">Цвет</label><input type="color" className="input" style={{ height: 46, padding: 4 }} value={newCat.color} onChange={e => setNewCat({...newCat, color: e.target.value})} /></div>
                </div>
                <div className="field"><label className="input-label">Описание</label><input className="input" placeholder="Описание раздела" value={newCat.description} onChange={e => setNewCat({...newCat, description: e.target.value})} /></div>
                <button className="btn btn-primary" onClick={addCategory}>+ Добавить раздел</button>
              </div>
              <div className={styles.catList}>
                {categories.map(c => (
                  <div key={c.id} className={styles.catRow}>
                    <div className={styles.catIcon2} style={{ background: c.color + '20', border: `1px solid ${c.color}40` }}>{c.icon}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 800 }}>{c.name}</div>
                      <div className="text-sm text-muted">/forum?cat={c.slug}</div>
                    </div>
                    <button className="btn btn-danger btn-sm" onClick={() => deleteCategory(c.id)}>🗑️</button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── ANNOUNCEMENTS ── */}
          {tab === 'announcements' && (
            <div className="animate-fade-up">
              <div className={styles.pageHeader}><h1 className={styles.pageTitle}>Объявления</h1></div>
              <div className={styles.formCard}>
                <h3 className={styles.formTitle}>Новое объявление</h3>
                <div className="field"><label className="input-label">Заголовок</label><input className="input" placeholder="Важное объявление" value={newAnnounce.title} onChange={e => setNewAnnounce({...newAnnounce, title: e.target.value})} /></div>
                <div className="field"><label className="input-label">Текст</label><textarea className="input" rows={3} placeholder="Текст объявления..." value={newAnnounce.body} onChange={e => setNewAnnounce({...newAnnounce, body: e.target.value})} /></div>
                <button className="btn btn-primary" onClick={addAnnouncement}>📢 Опубликовать</button>
              </div>
              <div className={styles.announceList}>
                {announcements.map(a => (
                  <div key={a.id} className={styles.announceRow}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 800, marginBottom: 4 }}>{a.title}</div>
                      <div className="text-sm text-muted">{a.body}</div>
                    </div>
                    <button className="btn btn-danger btn-sm" onClick={async () => { await fetch('/api/admin/manage?type=announcements', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: a.id }) }); load() }}>🗑️</button>
                  </div>
                ))}
                {announcements.length === 0 && <div className="text-muted" style={{ padding: 20, textAlign: 'center' }}>Нет объявлений</div>}
              </div>
            </div>
          )}

          {/* ── SETTINGS ── */}
          {tab === 'settings' && (
            <div className="animate-fade-up">
              <div className={styles.pageHeader}><h1 className={styles.pageTitle}>Настройки сайта</h1></div>
              <div className={styles.formCard}>
                <div className="field">
                  <label className="input-label">Описание сайта</label>
                  <input className="input" value={settings.site_description || ''} onChange={e => setSettings({...settings, site_description: e.target.value})} />
                </div>
                <div className="field">
                  <label className="input-label">Регистрация</label>
                  <select className="input" value={settings.allow_registration || 'true'} onChange={e => setSettings({...settings, allow_registration: e.target.value})}>
                    <option value="true">✅ Открыта</option>
                    <option value="false">🚫 Закрыта</option>
                  </select>
                </div>
                <div className="field">
                  <label className="input-label">Режим обслуживания</label>
                  <select className="input" value={settings.maintenance_mode || 'false'} onChange={e => setSettings({...settings, maintenance_mode: e.target.value})}>
                    <option value="false">✅ Выключен</option>
                    <option value="true">🔧 Включён</option>
                  </select>
                </div>
                <div className="field">
                  <label className="input-label">Макс. длина поста (символов)</label>
                  <input className="input" type="number" value={settings.max_post_length || '10000'} onChange={e => setSettings({...settings, max_post_length: e.target.value})} />
                </div>
                <button className="btn btn-primary" onClick={saveSettings}>💾 Сохранить настройки</button>
              </div>
            </div>
          )}
        </main>
      </div>
    </>
  )
}

export const getServerSideProps: GetServerSideProps = async (ctx) => {
  const session = await getSession()
  if (!session || session.role !== 'admin') {
    return { redirect: { destination: '/login', permanent: false } }
  }
  return { props: {} }
}
